module.exports = (sequelize, DataTypes) => {
  const Supervisor = sequelize.define(
    'Supervisor',
    {
      id: {
        // ...existing code...
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
      company_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        references: { model: 'companies', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
    },
    {
      tableName: 'supervisors',
      timestamps: false,
    },
  );

  Supervisor.associate = (models) => {
    Supervisor.belongsTo(models.Company, { foreignKey: 'company_id', as: 'company' });
    Supervisor.hasMany(models.Intern, { foreignKey: 'supervisor_id', as: 'interns' });
  };

  return Supervisor;
};
