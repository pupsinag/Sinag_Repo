/* eslint-env node */
const sequelize = require('../config/database');

/**
 * Add missing columns to intern_daily_logs table
 */
async function addMissingColumns() {
  try {
    // Check and add supervisor_approved_at column
    await sequelize.query(`
      ALTER TABLE intern_daily_logs 
      ADD COLUMN IF NOT EXISTS supervisor_approved_at DATETIME NULL 
      COMMENT 'Timestamp when supervisor approved'
    `);
    console.log('✅ Column supervisor_approved_at checked/added');

    // Check and add adviser_approved_at column
    await sequelize.query(`
      ALTER TABLE intern_daily_logs 
      ADD COLUMN IF NOT EXISTS adviser_approved_at DATETIME NULL 
      COMMENT 'Timestamp when adviser approved'
    `);
    console.log('✅ Column adviser_approved_at checked/added');

  } catch (err) {
    console.error('❌ Error adding missing columns:', err.message);
    throw err;
  }
}

module.exports = addMissingColumns;
